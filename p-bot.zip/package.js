{
  "name": "react-bot",
  "version": "1.0.0",
  "main": "index.js",
  "scripts": { "start": "node index.js" },
  "dependencies": {
    "@whiskeysockets/baileys": "latest",
    "axios": "latest",
    "pino": "latest",
    "readline-sync": "latest"
  }
}