const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys')
const pino = require('pino')
const axios = require('axios')
const readline = require('readline-sync')
const config = require('./config')
const { addLimit, getLimit } = require('./lib/limit')

const API_BASE = "https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app"
const API_KEY = "74a0043f754053fc334dc88fff85ffc6211b7d9669e611900a5bc328e0f535d9"

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState('./session')
  const sock = makeWASocket({
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    auth: state
  })

  // Pairing code sekali
  if (!sock.authState.creds.registered) {
    const phone = readline.question('Masukkan nomor WA (62xxx): ').trim()
    const code = await sock.requestPairingCode(phone.replace(/\D/g, ''))
    console.log(`\nPAIRING CODE: ${code}\nBuka WA > Perangkat Tertaut > Tautkan dengan nomor telepon > Masukkan kode!\n`)
  }

  sock.ev.on('connection.update', u => {
    if (u.connection === 'open') console.log(`${config.namaBot} ONLINE!`)
    if (u.connection === 'close' && u.lastDisconnect?.error?.output?.statusCode !== 401) start()
  })

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('messages.upsert', async m => {
    const msg = m.messages[0]
    if (!msg.message || msg.key.fromMe) return

    const from = msg.key.remoteJid
    const sender = msg.key.participant || from
    const text = (msg.message.conversation || msg.message.extendedTextMessage?.text || '').trim()
    if (!text.startsWith('/')) return

    const args = text.slice(1).trim().split(' ')
    const cmd = args[0].toLowerCase()
    const query = text.slice(cmd.length + 2).trim()

    const reply = teks => sock.sendMessage(from, { text: teks }, { quoted: msg })
    const isOwner = config.owner.includes(sender)

    switch (cmd) {
      case 'react':
        const used = getLimit(sender)
        if (!isOwner && used >= config.limitHarian) {
          return reply(`Limit harian kamu habis (\( {config.limitHarian}/ \){config.limitHarian})\nReset setiap jam 00:00`)
        }

        const [link, ...emojiRaw] = query.split(' ')
        const emojis = emojiRaw.join(' ').split(',').map(e => e.trim()).filter(Boolean).slice(0, 5)
        if (!link || emojis.length === 0) return reply('Contoh: /react https://whatsapp.com/channel/0029V... 😍,🔥')

        reply(`Sedang react ${emojis.length} emoji...`)
        try {
          await axios.post(`${API_BASE}/api/react`, { chat_link: link, emoji: emojis }, {
            headers: { Authorization: `Bearer ${API_KEY}` }
          })
          if (!isOwner) addLimit(sender)
          reply(`SUKSES! \( {emojis.join(' ')}\nLimit tersisa: \){isOwner ? '∞' : config.limitHarian - (used + 1)}`)
        } catch (e) {
          reply(`Gagal: ${e.response?.data?.message || e.message}`)
        }
        break

      case 'ceklimit':
      case 'limit':
        const tersisa = isOwner ? '∞ (Owner)' : config.limitHarian - getLimit(sender)
        reply(`Limit harian kamu: \( {tersisa}/ \){config.limitHarian}`)
        break

      case 'menu':
        reply(`*${config.namaBot}*\n\n/react <link> <emoji1,emoji2,...>\n/ceklimit → cek sisa limit\n/owner → kontak owner`)
        break

      case 'owner':
        config.owner.forEach(num => sock.sendContact(from, [num.replace('@s.whatsapp.net', '')], msg))
        reply('Owner bot di atas ↑')
        break

      default:
        reply('Perintah tidak dikenal. Ketik /menu')
    }
  })
}

start()