const config = {
  owner: ["628xxx@s.whatsapp.net"], // tambah nomor owner di sini
  limitHarian: 5, // maksimal react per hari per user (bisa diubah kapan saja)
  namaBot: "ReactBot"
}

module.exports = config